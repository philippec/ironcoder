License

This code can be freely used as long as these conditions are met:

1. This header, in its entirety, is kept with the code
2. It is not resold, in it's current form or in modified, as a
teaching utility or as part of a teaching utility

This code is presented as is. The author of the code takes no
responsibilities for any version of this code.

(c) 2007 Jonathan Saggau
Some Rights Reserved
jonathansaggau.com/blog
jonathan@jonathansaggau.com

*********************************************************************/
Some code from Rocco Bowling at the Big Nerd Ranch.  Thanks Rocco!

Instructions:
Install as normal for a screen saver.
You may want to turn on the sound options. (Hint: yes!)

